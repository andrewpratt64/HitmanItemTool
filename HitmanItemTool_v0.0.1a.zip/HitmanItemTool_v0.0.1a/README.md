# HitmanItemTool
 A utility for configuring items in Hitman 3
 Version 0.0.1-Alpha
 
DOCUMENTATION AND INSTRUCTIONS ARE A WORK-IN-PROGRESS

Requires Nodejs: https://nodejs.org/en/download/
Requires RPKGTool: https://notex.app/rpkg/
Requires ORESTool: https://discord.com/channels/555224628251852811/815577522958893096/858685324103778344

Run via easy_run.bat, or execute main.js from nodejs
Change settings in HitmanItemTool/src/dat/config.json BEFORE running